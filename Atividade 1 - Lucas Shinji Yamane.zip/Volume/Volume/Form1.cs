﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Volume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double check1, check2;
            if (double.TryParse(txtAlt.Text, out check1) && double.TryParse(txtRaio.Text, out check2) & check2 > 0 & check1 > 0)
            {
                double resultado = Math.PI * Math.Pow(check2, 2) * check1;
                txtVol.Text = resultado.ToString("N2");
            }
            else
                MessageBox.Show("Dados Inválidos!!!");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAlt.Clear();
            txtRaio.Clear();
            txtVol.Clear();
        }
    }
}
