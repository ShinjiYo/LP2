﻿namespace Funcionario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblAliquotaIRFF = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRFF = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.grpSexo = new System.Windows.Forms.GroupBox();
            this.radF = new System.Windows.Forms.RadioButton();
            this.radM = new System.Windows.Forms.RadioButton();
            this.grpEstadoCivil = new System.Windows.Forms.GroupBox();
            this.chkCasado = new System.Windows.Forms.CheckBox();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.txtSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtNumFilhos = new System.Windows.Forms.MaskedTextBox();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRFF = new System.Windows.Forms.TextBox();
            this.txtAliquotaIRFF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.grpSexo.SuspendLayout();
            this.grpEstadoCivil.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(25, 32);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(108, 13);
            this.lblNomeFunc.TabIndex = 0;
            this.lblNomeFunc.Text = "Nome do Funcionario";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(25, 75);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(25, 118);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(13, 220);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(38, 13);
            this.lblDados.TabIndex = 3;
            this.lblDados.Text = "Dados";
            // 
            // lblAliquotaIRFF
            // 
            this.lblAliquotaIRFF.AutoSize = true;
            this.lblAliquotaIRFF.Location = new System.Drawing.Point(25, 338);
            this.lblAliquotaIRFF.Name = "lblAliquotaIRFF";
            this.lblAliquotaIRFF.Size = new System.Drawing.Size(73, 13);
            this.lblAliquotaIRFF.TabIndex = 4;
            this.lblAliquotaIRFF.Text = "Alíquota IRFF";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Location = new System.Drawing.Point(25, 301);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(75, 13);
            this.lblAliquotaINSS.TabIndex = 5;
            this.lblAliquotaINSS.Text = "Alíquota INSS";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(238, 301);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescINSS.TabIndex = 6;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRFF
            // 
            this.lblDescIRFF.AutoSize = true;
            this.lblDescIRFF.Location = new System.Drawing.Point(238, 338);
            this.lblDescIRFF.Name = "lblDescIRFF";
            this.lblDescIRFF.Size = new System.Drawing.Size(79, 13);
            this.lblDescIRFF.TabIndex = 7;
            this.lblDescIRFF.Text = "Desconto IRFF";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(25, 416);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiquido.TabIndex = 8;
            this.lblSalLiquido.Text = "Salário Liquído";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(25, 383);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalFamilia.TabIndex = 9;
            this.lblSalFamilia.Text = "Salário Familía";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(104, 166);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(145, 39);
            this.btnVerificar.TabIndex = 7;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // grpSexo
            // 
            this.grpSexo.Controls.Add(this.radM);
            this.grpSexo.Controls.Add(this.radF);
            this.grpSexo.Location = new System.Drawing.Point(321, 29);
            this.grpSexo.Name = "grpSexo";
            this.grpSexo.Size = new System.Drawing.Size(140, 99);
            this.grpSexo.TabIndex = 11;
            this.grpSexo.TabStop = false;
            this.grpSexo.Text = "Sexo";
            // 
            // radF
            // 
            this.radF.AutoSize = true;
            this.radF.Location = new System.Drawing.Point(29, 20);
            this.radF.Name = "radF";
            this.radF.Size = new System.Drawing.Size(31, 17);
            this.radF.TabIndex = 4;
            this.radF.TabStop = true;
            this.radF.Text = "F";
            this.radF.UseVisualStyleBackColor = true;
            // 
            // radM
            // 
            this.radM.AutoSize = true;
            this.radM.Location = new System.Drawing.Point(29, 43);
            this.radM.Name = "radM";
            this.radM.Size = new System.Drawing.Size(34, 17);
            this.radM.TabIndex = 5;
            this.radM.TabStop = true;
            this.radM.Text = "M";
            this.radM.UseVisualStyleBackColor = true;
            // 
            // grpEstadoCivil
            // 
            this.grpEstadoCivil.Controls.Add(this.chkCasado);
            this.grpEstadoCivil.Location = new System.Drawing.Point(321, 133);
            this.grpEstadoCivil.Name = "grpEstadoCivil";
            this.grpEstadoCivil.Size = new System.Drawing.Size(140, 100);
            this.grpEstadoCivil.TabIndex = 2;
            this.grpEstadoCivil.TabStop = false;
            // 
            // chkCasado
            // 
            this.chkCasado.AutoSize = true;
            this.chkCasado.Location = new System.Drawing.Point(29, 34);
            this.chkCasado.Name = "chkCasado";
            this.chkCasado.Size = new System.Drawing.Size(62, 17);
            this.chkCasado.TabIndex = 6;
            this.chkCasado.Text = "Casado";
            this.chkCasado.UseVisualStyleBackColor = true;
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(139, 29);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(100, 20);
            this.txtNomeFunc.TabIndex = 1;
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Location = new System.Drawing.Point(139, 72);
            this.txtSalBruto.Mask = "999000.99";
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalBruto.TabIndex = 2;
            // 
            // txtNumFilhos
            // 
            this.txtNumFilhos.Location = new System.Drawing.Point(139, 115);
            this.txtNumFilhos.Mask = "90";
            this.txtNumFilhos.Name = "txtNumFilhos";
            this.txtNumFilhos.Size = new System.Drawing.Size(100, 20);
            this.txtNumFilhos.TabIndex = 3;
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Location = new System.Drawing.Point(106, 298);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.ReadOnly = true;
            this.txtAliquotaINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaINSS.TabIndex = 8;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Location = new System.Drawing.Point(340, 298);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.ReadOnly = true;
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 10;
            // 
            // txtDescIRFF
            // 
            this.txtDescIRFF.Location = new System.Drawing.Point(340, 335);
            this.txtDescIRFF.Name = "txtDescIRFF";
            this.txtDescIRFF.ReadOnly = true;
            this.txtDescIRFF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRFF.TabIndex = 11;
            // 
            // txtAliquotaIRFF
            // 
            this.txtAliquotaIRFF.Location = new System.Drawing.Point(104, 335);
            this.txtAliquotaIRFF.Name = "txtAliquotaIRFF";
            this.txtAliquotaIRFF.ReadOnly = true;
            this.txtAliquotaIRFF.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaIRFF.TabIndex = 9;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(104, 380);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.ReadOnly = true;
            this.txtSalFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalFamilia.TabIndex = 12;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Location = new System.Drawing.Point(104, 413);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.ReadOnly = true;
            this.txtSalLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiquido.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 534);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliquotaIRFF);
            this.Controls.Add(this.txtDescIRFF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.txtNumFilhos);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.grpEstadoCivil);
            this.Controls.Add(this.grpSexo);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblDescIRFF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.lblAliquotaIRFF);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Name = "Form1";
            this.Text = "Calcular";
            this.grpSexo.ResumeLayout(false);
            this.grpSexo.PerformLayout();
            this.grpEstadoCivil.ResumeLayout(false);
            this.grpEstadoCivil.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblAliquotaIRFF;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRFF;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.GroupBox grpSexo;
        private System.Windows.Forms.RadioButton radM;
        private System.Windows.Forms.RadioButton radF;
        private System.Windows.Forms.GroupBox grpEstadoCivil;
        private System.Windows.Forms.CheckBox chkCasado;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.MaskedTextBox txtSalBruto;
        private System.Windows.Forms.MaskedTextBox txtNumFilhos;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRFF;
        private System.Windows.Forms.TextBox txtAliquotaIRFF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
    }
}

