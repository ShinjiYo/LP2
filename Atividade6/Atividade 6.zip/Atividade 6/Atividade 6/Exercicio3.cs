﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if(txtTexto.Text.Length <= 50)
            {
                txtTexto.Text = txtTexto.Text.ToUpper();
                txtTexto.Text = txtTexto.Text.Replace(" ", "");
                string s = txtTexto.Text;
                char[] arr = s.ToCharArray();
                Array.Reverse(arr);
                s = "";
                foreach (char c in arr)
                    s = s + c.ToString();
                if(s == txtTexto.Text)
                {
                    MessageBox.Show("É palíndromo!");
                }
                else
                {
                    MessageBox.Show("Não é palíndromo!");
                }
            }
        }
    }
}
