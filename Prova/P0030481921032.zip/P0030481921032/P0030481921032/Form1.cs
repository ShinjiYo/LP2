﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030481921032
{
    public partial class frmProva : Form
    {
        public frmProva()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[2, 4];
            int semana, mes, y = 0;
            string numero = "";
            double totMes = 0, totGeral = 0;
            for (mes = 0; mes < 2; mes++)
            {
                for (semana = 0; semana < 4; semana++)
                {
                    y = 0;
                    while (y == 0)
                    {
                        numero = Interaction.InputBox("Digite o valor arrecadado na semana(" + (semana + 1) + ") do mês(" + (mes + 1)+")", "Entrada de dados");
                        if (double.TryParse(numero, out matriz[mes, semana]))
                        {
                            lstInfo.Items.Add("Total da Semana(" + (semana + 1) + ") do Mês(" + (mes+1) + "): R$:"+ matriz[mes,semana].ToString("N2"));
                            totMes += matriz[mes, semana];
                            if(semana == 3)
                            {
                                lstInfo.Items.Add(">>Total do Mês(" + (mes + 1) +") = R$" + totMes.ToString("N2"));
                                lstInfo.Items.Add("----------------------------------------------------------------------------------------");
                                totGeral += totMes;
                                totMes = 0;
                            }
                            y = 1;
                      
                        }
                        else
                        {

                            MessageBox.Show("Dado Inválido!");
                        }

                    }

                }
            }
            lstInfo.Items.Add(">>>>Total Geral: R$" + totGeral.ToString("N2"));
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstInfo.Items.Clear();
        }
    }
}
